package com.example.blogengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogEngineWebApp {
    public static void main(String[] args) {
        SpringApplication.run(BlogEngineWebApp.class, args);
    }
}
