# Apc-Vedansh
This a Spring App named as BlogEngine performs crud in GUI + CLI.
